# Personal Finance Advisor Bot 💰🤖

An AI-powered financial planning assistant built with **React 19**, **TypeScript**, **Tailwind CSS v4**, **Express**, and the **Google Gemini API (@google/genai)**.

The platform enables users to record monthly income, log daily and weekly expenses by category, receive personalized budget plans, track goal-based savings, simulate stress-test scenarios, and generate structured monthly financial reports.

---

## 🚀 Quick Start (Run on Local Browser)

### 1. Prerequisites
- **Node.js**: Version 18.0.0 or higher (Node 20+ recommended)
- **npm**: Version 9.0.0 or higher (or pnpm / yarn)

### 2. Installation
Open your terminal in the project directory and install all required dependencies:

```bash
npm install
```

### 3. Configure Environment Variables
Create a `.env` file in the root directory by copying the example:

```bash
cp .env.example .env
```

Open `.env` and configure your Gemini API Key (get a free key at [Google AI Studio](https://aistudio.google.com/)):

```env
GEMINI_API_KEY="your_actual_gemini_api_key_here"
PORT=3000
```

> **Note**: Even without an API key, the platform operates seamlessly using a built-in deterministic financial intelligence fallback engine!

### 4. Run the Development Server
Start the local full-stack server (runs Express backend + Vite frontend with hot reloading):

```bash
npm run dev
```

### 5. Open in Your Browser
Open your browser and navigate to:
```
http://localhost:3000
```

---

## 📦 How to Push this Project to GitHub

Follow these steps in your local terminal:

### Step 1: Initialize Git
```bash
git init
```

### Step 2: Add all files
```bash
git add .
```

### Step 3: Create initial commit
```bash
git commit -m "feat: initial release of Personal Finance Advisor Bot"
```

### Step 4: Rename branch to `main`
```bash
git branch -M main
```

### Step 5: Link to your GitHub Repository
Go to [github.com/new](https://github.com/new) and create a new repository (e.g., `personal-finance-advisor-bot`). Then run:

```bash
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/personal-finance-advisor-bot.git
```
*(Replace `YOUR_GITHUB_USERNAME` and the repository name with your actual GitHub repository details)*

### Step 6: Push your code
```bash
git push -u origin main
```

---

## 🛠 Available Scripts

- `npm run dev`: Starts the full-stack server with Vite middlewares on port `3000`
- `npm run build`: Compiles the TypeScript code and bundles production assets with Vite
- `npm run lint`: Runs TypeScript compiler (`tsc --noEmit`) to check for type issues
- `npm run clean`: Cleans the build output directory

---

## 📂 Project Architecture

```
├── .env.example                # Example environment variables
├── .gitignore                  # Git ignore rules (node_modules, .env, dist)
├── index.html                  # HTML entry point with Google Fonts
├── metadata.json               # Applet metadata configuration
├── package.json                # Project dependencies and npm scripts
├── server.ts                   # Full-stack Express server + Gemini AI endpoints
├── tsconfig.json               # TypeScript compiler configuration
├── vite.config.ts              # Vite & Tailwind CSS v4 setup
└── src/
    ├── main.tsx                # React application root
    ├── index.css               # Tailwind CSS v4 imports and print stylesheets
    ├── App.tsx                 # Main application state and tab router
    ├── types/
    │   └── finance.ts          # Core data models (Transactions, Budgets, Goals, Reports)
    ├── data/
    │   └── defaultScenarios.ts # Pre-seeded data for the 4 core scenarios
    └── components/
        ├── Header.tsx              # Universal 3-zone Top Bar & Scenario selector
        ├── OverviewCards.tsx       # 4 core metric cards + 50/30/20 distribution gauge
        ├── BudgetPlanner.tsx       # Interactive category limits & AI budget generator
        ├── TransactionLedger.tsx   # Income & expense tracker with filters & CSV export
        ├── SavingsGoals.tsx        # Goal-based savings milestones & emergency runway
        ├── MonthlyReportModal.tsx  # Printable statement with AI executive analysis
        ├── AdvisorChatDrawer.tsx   # Interactive Gemini AI Financial Advisor bot
        ├── AddTransactionModal.tsx # Log new income/expense modal
        └── PredictiveAnalytics.tsx # Velocity run-rate & stress-testing simulator
```

---

## ✨ Features & Scenarios Supported

- **Scenario 1 (Salaried Professional)**: Monthly salary tracking, fixed rent/commute outlays, discretionary dining trim recommendations, 50/30/20 balance.
- **Scenario 2 (College Student)**: Constrained monthly stipend, campus expenses vs dining out, student discount optimizations, emergency laptop buffer.
- **Scenario 3 (Freelancer)**: Multi-client invoices, project software costs, 30% tax withholding reserve, 6-month living expense cushion.
- **Scenario 4 (Household Manager)**: Shared family incomes, childcare, mortgage, bulk grocery planning, children's 529 college fund.
- **Exporting & Printing**: One-click CSV ledger export and printable formatted monthly financial statements.

---

## 📄 License
Apache-2.0
